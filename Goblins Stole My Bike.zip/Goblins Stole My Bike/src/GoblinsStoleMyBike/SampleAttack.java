package GoblinsStoleMyBike;

public class SampleAttack extends Attack{
    
    public SampleAttack() {
        this.name = "Punch";
        this.desc = "Deck 'em in the face.";
        this.img = DEFAULT;
        this.element = new Element();
        this.power = 25.0;
        this.statusEffect = NULL;
        this.statusChance = 0;
    }
    
    
    /*///
    Damage formula defined in Attack class
    This can be overriden in subclasses for special attack effects
    For example, here is an attack that would cut the enemy's health in half
    
    @Override
    public double calcDamage(Monster source, Monster target) {
        return target.getCurrHp() * 0.5;
    }
    
    ///*/
}
