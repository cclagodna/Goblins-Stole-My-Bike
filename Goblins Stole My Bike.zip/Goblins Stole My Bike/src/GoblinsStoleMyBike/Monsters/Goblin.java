package GoblinsStoleMyBike.Monsters;
import GoblinsStoleMyBike.*;
import GoblinsStoleMyBike.Attacks.*;

public class Goblin extends Monster{
    
    private final double hp = calcBaseHp();
    private final double atk = calcBaseAtk();
    private final double def = calcBaseDef();
    
    public Goblin() {
        this.name = "Goblin";
        this.desc = "Just a simple goblin. Has a rabid fascination with bicycles.";
        this.img = DEFAULT;
        this.element = "basic";
        this.base_hp = hp;
        this.base_atk = atk;
        this.base_def = def;
        this.att1 = new Kick();
        /*
        this.att2;
        this.att3;
        this.att4;
        */
        
    }
    
    
    public void levelUp() {
        //Max level is 5
        if (level < 5) this.level++;
        this.base_hp = calcBaseHp();
        this.base_atk = calcBaseAtk();
        this.base_def = calcBaseDef();
        unlockNewAttack();
    }

    //Below are formulas that calculate monster stats based on its level
    public double calcBaseHp() {
        //Lv 1 - 5: 21, 27, 33, 39, 45
        return Math.floor(15 + level * 6);
    }
    
    public double calcBaseAtk() {
        //Lv 1 - 5: 10, 12, 14, 16, 19
        return Math.floor(8 + level * 2.2);
    }
    
    public double calcBaseDef() {
        //Lv 1 - 5: 7, 8, 9, 10, 11
        return Math.floor(7 + level);
    }
    
    public void unlockNewAttack() {      
    }
    
    
    
}
