package GoblinsStoleMyBike.Monsters;
import GoblinsStoleMyBike.*;
import GoblinsStoleMyBike.Attacks.*;

public class Goblin extends Monster{
    
    final double hp = calcBaseHp();
    final double atk = calcBaseAtk();
    final double def = calcBaseDef();
    
    public Goblin() {
        this.name = "Goblin";
        this.desc = "Just a simple goblin. Has a rabid fascination with bicycles.";
        this.img = DEFAULT;
        this.element = "basic";
        this.base_hp = this.curr_hp = hp;
        this.base_atk = this.curr_atk = atk;
        this.base_def = this.curr_def = def;
        this.att1 = new Kick();
        /*
        this.att2;
        this.att3;
        this.att4;
        */
        
    }
    
    public void levelUp() {
        //Max level is 5
        if (level < 5) this.level++;
        this.base_hp = calcBaseHp();
        this.base_atk = calcBaseAtk();
        this.base_def = calcBaseDef();
        unlockNewAttack();
    }

    //Below are formulas that calculate monster stats based on its level
    public double calcBaseHp() {
        //Lv 1 - 5: 33, 41, 49, 57, 65
        return Math.floor(25 + level * 8);
    }
    
    public double calcBaseAtk() {
        //Lv 1 - 5: 14, 18, 22, 26, 30
        return Math.floor(10 + level * 4);
    }
    
    public double calcBaseDef() {
        //Lv 1 - 5: 13, 16, 19, 22, 25
        return Math.floor(10 + level * 3);
    }
    
    public void unlockNewAttack() {      
    }
    
    
    
}
