package GoblinsStoleMyBike;

public class Element {
    
    enum elem {
        NULL, BASIC, GRASS, FIRE, WATER, EARTH, SHOCK, WIND, MAGIC, GHOST, CORROSIVE, MACHINE, MUTANT, SPACE
    }
    
    elem primary;
    elem secondary;
    
    public Element() {
        this("basic", "basic");
    }
    
    public Element(String primary) {
        this(primary, null);
    }
    
    public Element(String primary, String secondary) {
        
    }
    
    public void typeChart() {
        
    }
}
