package GoblinsStoleMyBike;


public class test {
    
    /*
    For NetBeans:
    For changes of code to show in console, Run -> Clean and Build (SHIFT + F11)
    Then, to test code, Run -> Run File (SHIFT + F6)
    Generally: SHIFT + F11 -> SHIFT + F6
    */
    
    public static void main(String args[]) {
        
        SampleMonster mon1 = new SampleMonster();
        
        System.out.printf("Monster Name: %s%n", mon1.getName());
        System.out.printf("Description: %s%n", mon1.getDesc());
        System.out.printf("Image: %s%n", mon1.getImg());
        System.out.printf("Element: %s%n", mon1.getElement());
        System.out.printf("Base HP:  %s%n", mon1.getBaseHp());
        System.out.printf("Base Atk: %s%n", mon1.getBaseAtk());
        System.out.printf("Base Def: %s%n", mon1.getBaseDef());
        
    }
    
}
