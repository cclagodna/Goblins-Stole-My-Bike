package GoblinsStoleMyBike;
import GoblinsStoleMyBike.Monsters.*;
import java.util.Scanner;
import java.util.concurrent.ThreadLocalRandom;

public class Battle {
    
    /*///
        0. Battle Starts
        1. Determine who goes first
        2. Loop until player or enemy dies (HP <= 0)
          (Assume Player is going first)
          a. Player's turn. Wait until Player chooses attack, action, or item
          b. Enemy health decreases, effects resolve, item or attack uses decreases
          c. Enemy randomly chooses attack
          d. Player health decreases, effects resolve
        3. If Player dies...
          a. Battle ends. Player loses gold, experience, etc.
        4. If enemy dies...
          a. Player gains gold, experience, items, etc
    ///*/
    
    static public void startBattle() {
        
        Scanner input = new Scanner(System.in);
        int attNum = 0;
        int enemyAttNum;
        
        Goblin player = new Goblin();
        Goblin enemy = new Goblin();
        
        while (player.getCurrHp() > 0 && enemy.getCurrHp() > 0) {
            
            System.out.printf("Player HP: %.1f%n", player.getCurrHp());
            System.out.printf("Enemy HP: %.1f%n", enemy.getCurrHp());
            
            System.out.printf("Type 1 - 4 then ENTER to select an attack:%n");
            System.out.printf("(1) %s%n", player.getAtt1().getName());
            System.out.printf("(2) %s%n", player.getAtt2().getName());
            System.out.printf("(3) %s%n", player.getAtt3().getName());
            System.out.printf("(4) %s%n", player.getAtt4().getName());
            //Will loop until player chooses numbers 1, 2, 3, or 4
            
            while (attNum != 1 && attNum != 2 && attNum != 3 && attNum != 4) {
                System.out.printf("Attack: ");
                attNum = input.nextInt();
            }
            switch(attNum){
                case 1:
                    enemy.takeDamage(player.getAtt1().calcDamage(player, enemy));
                    break;
                case 2:
                    enemy.takeDamage(player.getAtt2().calcDamage(player, enemy));
                    break;
                case 3:
                    enemy.takeDamage(player.getAtt3().calcDamage(player, enemy));
                    break;
                case 4:
                    enemy.takeDamage(player.getAtt4().calcDamage(player, enemy));
                    break;
            }
            //Reset attNum
            attNum = 0;
            
            //Choose a random int 1 - 4
            //nextInt(min, max + 1) Must add 1 to max or else it will pick 1 - 3
            enemyAttNum = ThreadLocalRandom.current().nextInt(1, 5);
            
            switch(enemyAttNum){
                case 1:
                    player.takeDamage(enemy.getAtt1().calcDamage(enemy, player));
                    break;
                case 2:
                    player.takeDamage(enemy.getAtt2().calcDamage(enemy, player));
                    break;
                case 3:
                    player.takeDamage(enemy.getAtt3().calcDamage(enemy, player));
                    break;
                case 4:
                    player.takeDamage(enemy.getAtt4().calcDamage(enemy, player));
                    break;
            }
        }
        
        /*///
        TO-DO:
            Give gold/ money to player for defeating monster
        ///*/
        
        System.out.printf("Battle is over!%n");
        System.out.printf("Player: %.0f%n", player.getCurrHp());
        System.out.printf("Enemy: %.0f%n", enemy.getCurrHp());
        
    }

}
