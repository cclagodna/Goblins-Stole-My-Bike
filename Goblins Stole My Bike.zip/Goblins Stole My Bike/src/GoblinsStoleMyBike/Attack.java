package GoblinsStoleMyBike;

public class Attack extends Base_Object {
    
    /*/// Inherited from 'Base_Object'
    final String NULL
    final Image DEFAULT
    String name
    String desc
    Image img
    ///*/
    
    protected Element element;
    protected double power = 1;
    //Currently String, data type likely will change
    protected String statusEffect = NULL;
    protected double statusChance = 0;
    
    //Constructors
    //See 'Base_Object' class for notes
    public Attack() {
        this(null, null, null, -1, null, -1);
    }
    
    public Attack(String name) {
        this(name, null, null, -1, null, -1);
    }
    
    public Attack(String name, String desc) {
        this(name, desc, null, -1, null, -1);
    }
    
    public Attack(String name, String desc, String element) {
        this(name, desc, element, -1, null, -1);
    }
    
    public Attack(String name, String desc, String element, double power) {
        this(name, desc, element, power, null, -1);
    }
    
    public Attack(String name, String desc, String element, double power, String statusEffect) {
        this(name, desc, element, power, statusEffect, -1);
    }
    
    public Attack(String name, String desc, String element, double power, String statusEffect, double statusChance) {
        //null is an Image object
        super(name, desc, null);
        this.element = new Element(element);
        this.power = power;
        this.statusEffect = statusEffect;
        this.statusChance = statusChance;
    }
    //Constructors
    
    //Get and Set Methods
    public Element getElement() {return element;}
    public void setElement(String element) {this.element = new Element(element);}
    
    public double getPower() {return power;}
    public void setPower(double power) {this.power = power;}
    
    public String getStatusEffect() {return statusEffect;}
    public void setStatusEffect(String statusEffect) {this.statusEffect = statusEffect;}
    
    public double getStatusChance() {return statusChance;}
    public void setStatusChance(double statusChance) {this.statusChance = statusChance;}
    //Get and Set Methods
    
    
    
    public double calcDamage(Monster source, Monster target) {
        //TO-DO: Revise formula to account for element weakness/ resistance
        //Add a "damage multiplier" to end of formula
        
        // damage = (monA Atk)(Attack Power) / ((monA Atk) + (monB Def))
        return (source.getCurrAtk() * this.getPower()) / (source.getCurrAtk() + target.getCurrDef());
    }
    
    
    
    //To be continued...
    //
    //
    //
    //
}
