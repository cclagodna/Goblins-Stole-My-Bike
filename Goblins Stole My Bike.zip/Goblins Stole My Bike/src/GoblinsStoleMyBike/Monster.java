package GoblinsStoleMyBike;

import javafx.scene.image.Image;

public class Monster extends Base_Object {
    
    //The level of the monster, influences base stats
    protected int level = 1;
    //Elemental type of monster. Currently 'String' data type, may change
    protected String element = NULL;
    //Base stat values of monster
    protected double base_hp = 1;
    protected double base_atk = 1;
    protected double base_def = 1;
    //Current stat values for monster
    //These will change during battle
    protected double curr_hp = base_hp;
    protected double curr_atk = base_atk;
    protected double curr_def = base_def;
    
    //The Attacks of the monster
    protected Attack att1 = new Attack();
    protected Attack att2 = new Attack();
    protected Attack att3 = new Attack();
    protected Attack att4 = new Attack();
    
    public Monster() {
        this.name = name;
    }
    
    //Get and Set Methods
    public String getElement() {return element;}
    public void setElement(String element) {this.element = element;}
    
    public double getBaseHp() {return base_hp;}
    public void setBaseHp(double base_hp) {this.base_hp = base_hp;}
    
    public double getBaseAtk() {return base_atk;}
    public void setBaseAtk(double base_atk) {this.base_atk = base_atk;}
    
    public double getBaseDef() {return base_def;}
    public void setBaseDef(double base_def) {this.base_def = base_def;}
    
    public double getCurrHp() {return curr_hp;}
    public void setCurrHp(double curr_hp) {this.curr_hp = curr_hp;}
    
    public double getCurrAtk() {return curr_atk;}
    public void setCurrAtk(double curr_atk) {this.curr_atk = curr_atk;}
    
    public double getCurrDef() {return curr_def;}
    public void setCurrDef(double curr_def) {this.curr_def = curr_def;}
    
    public Attack getAtt1() {return att1;}
    public void setAtt1(Attack att) {att1 = att;}
    
    public Attack getAtt2() {return att2;}
    public void setAtt2(Attack att) {att2 = att;}
    
    public Attack getAtt3() {return att3;}
    public void setAtt3(Attack att) {att3 = att;}
    
    public Attack getAtt4() {return att4;}
    public void setAtt4(Attack att) {att4 = att;}
    //Get and Set Methods
    
    public void takeDamage(double damage) {
        this.setCurrHp( this.getCurrHp() - damage );
    }
    
    //To be continued...
    //
    //
    //
    //
}
