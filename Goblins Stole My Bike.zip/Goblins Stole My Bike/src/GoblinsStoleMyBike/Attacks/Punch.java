package GoblinsStoleMyBike.Attacks;

import GoblinsStoleMyBike.*;

public class Punch extends Attack{
    
    public Punch() {
        this.name = "Punch";
        this.desc = "Deck 'em in the face.";
        this.img = DEFAULT;
        //this.element = "basic";
        this.power = 25.0;
        this.statusEffect = NULL;
        this.statusChance = 0;
    }
}
