package GoblinsStoleMyBike.Attacks;
import GoblinsStoleMyBike.*;

public class Kick extends Attack{
    
    public Kick() {
        this.name = "Kick";
        this.desc = "Kick 'em in the face.";
        this.img = DEFAULT;
        //this.element;
        this.power = 20.0;
        this.statusEffect = NULL;
        this.statusChance = 0;
    }
    
    /*///
    //Use this method if an attack has a special damage formula
    
    @Override
    public double calcDamage(){}
    ///*/
}
